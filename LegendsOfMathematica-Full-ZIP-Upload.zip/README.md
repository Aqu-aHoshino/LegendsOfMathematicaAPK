# Legends Of Mathematica — Android source project

A native Android Java prototype for the isometric medieval RPG concept. It uses Android's
`SurfaceView` and `Canvas` directly; no Unity, Godot, LibGDX, or external game engine is used.

## Uploading the project as a ZIP

The project ZIP includes the Android source and a GitHub Actions workflow.

**GitHub limitation:** GitHub does not automatically unpack ZIP files uploaded to a repository,
and it only recognizes workflow files that are already placed in the repository at
`.github/workflows/`. Therefore, the workflow must be added to the repository once before
ZIP-only updates can trigger automatic builds.

For the initial setup:
1. Create a GitHub repository.
2. Add the workflow file from `.github/workflows/android-build.yml` to the repository at that exact path.
3. Upload this project archive to the repository root, naming it
   `LegendsOfMathematica-Android-Source.zip`.
4. The workflow extracts the archive, builds the Android app, and uploads the APK artifact.

For later updates, replace `LegendsOfMathematica-Android-Source.zip` in the repository.
The workflow will run automatically when that ZIP changes.

## Download the APK

When the GitHub Actions run finishes successfully:
1. Open the completed run under the repository's **Actions** tab.
2. Find **Artifacts**.
3. Download `LegendsOfMathematica-debug-apk`.
4. Extract the downloaded artifact ZIP to get `app-debug.apk`.

## Build locally

Open the project root in Android Studio, allow Gradle sync, then run the `app` configuration.
Alternatively, with Java 17 and Android SDK installed, run:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Current playable prototype

- Landscape-only Android app with a custom pixel-style isometric renderer.
- Knight and Mage visual choices.
- Main menu, settings, level select, pause, inventory, victory and defeat screens.
- 30-stage progression structure and boss encounter every fifth stage.
- Touch movement area, attack and skill buttons.
- Enemies pursue the player and have health bars.
- Math chest challenges with Easy, Normal and Hard question generation.
- Gold, weapon upgrades, XP and attribute-point allocation.
- Procedural Canvas graphics and synthesized tone effects; no external art/audio files required.

## Controls

- Drag or touch the bottom-left MOVE area to move.
- Tap ATTACK to strike nearby enemies.
- Tap SKILL to use the class skill (mana cost and cooldown).
- Walk close to a chest and tap OPEN CHEST, then enter the answer with the on-screen number pad.
- BAG opens inventory; PAUSE opens the pause menu.

## Notes

This is a prototype/gameplay foundation, not yet the complete production game described in the design brief.
