package com.mathematica.game;

import android.content.Context;
import android.graphics.*;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import java.util.*;

public class GameView extends SurfaceView implements SurfaceHolder.Callback, Runnable {
    private final SurfaceHolder holder;
    private Thread thread;
    private volatile boolean running = false;
    private boolean pausedBySystem = false;
    private final Paint p = new Paint();
    private final Random random = new Random();
    private ToneGenerator tones;
    private long lastFrame = 0, lastAttack = 0, lastSkill = 0;
    private float scale = 1, offsetX, offsetY;
    private int screenW = 960, screenH = 540;

    private enum Screen { MENU, PLAYING, TUTORIAL, CHEST, PAUSE, CLEARED, DEFEAT, LEVELS, SETTINGS, INVENTORY }
    private Screen screen = Screen.MENU;
    private String playerName = "Knight", hero = "Knight", difficulty = "Normal";
    private String toast = "";
    private long toastUntil = 0;
    private int level = 1, maxUnlocked = 1, sessionBest = 0, enemiesDefeated = 0;
    private int gold = 0, stageGold = 0, weaponPower = 1, armor = 0;
    private int hp = 120, maxHp = 120, mana = 60, maxMana = 60, xp = 0, playerLevel = 1, points = 0;
    private int attackStat = 0, speedStat = 0, manaStat = 0, durabilityStat = 0;
    private float px = 0, py = 0, joystickX, joystickY;
    private boolean joystickActive = false, attacking = false;
    private long skillReadyAt = 0;
    private boolean chestNearby = false;
    private int chestX = 2, chestY = 2;
    private boolean chestSolved = false;
    private String question = "", answer = "";
    private int correctAnswer;
    private int selectedAttribute = 0;
    private final ArrayList<Enemy> enemies = new ArrayList<>();
    private final ArrayList<Chest> chests = new ArrayList<>();
    private final ArrayList<Particle> particles = new ArrayList<>();
    private final String[] bossNames = {"Malakor the Bone King", "Ignis Flame Warlord", "Veyra the Crystal Witch",
            "Dreadlord Umbrax", "Abyssal Emperor"};
    private final String[] chapters = {"Green Outskirts", "Forgotten Dungeons", "Lava Ruins",
            "Crystal Spire", "Void Throne", "The Final Eclipse"};

    private static class Enemy {
        float x, y, hp, maxHp, speed;
        int type;
        boolean boss;
        String name;
        Enemy(float x, float y, int type, boolean boss, float health, String name) {
            this.x=x; this.y=y; this.type=type; this.boss=boss; hp=maxHp=health; speed=boss?17:22; this.name=name;
        }
    }
    private static class Chest { float x,y; boolean opened=false; Chest(float x,float y){this.x=x;this.y=y;} }
    private static class Particle { float x,y,vx,vy,life; String text; int color; Particle(float x,float y,String t,int c){this.x=x;this.y=y;text=t;color=c;vx=(float)(Math.random()*30-15);vy=-35;life=1;} }

    public GameView(Context c) {
        super(c);
        holder = getHolder();
        holder.addCallback(this);
        setFocusable(true);
        p.setAntiAlias(false);
        p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        try { tones = new ToneGenerator(AudioManager.STREAM_MUSIC, 45); } catch(Exception ignored) {}
    }

    @Override public void surfaceCreated(SurfaceHolder h) { startLoop(); }
    @Override public void surfaceChanged(SurfaceHolder h,int f,int w,int he) { screenW=w; screenH=he; }
    @Override public void surfaceDestroyed(SurfaceHolder h) { stopLoop(); }

    public void pauseGame() { pausedBySystem=true; }
    public void resumeGame() { pausedBySystem=false; if(getHolder().getSurface().isValid()) startLoop(); }
    private void startLoop() { if(thread==null || !thread.isAlive()){ running=true; thread=new Thread(this,"MathematicaLoop"); thread.start(); } }
    private void stopLoop() { running=false; if(thread!=null){try{thread.join(500);}catch(InterruptedException ignored){} thread=null;} }

    @Override public void run() {
        while(running) {
            if(!pausedBySystem && holder.getSurface().isValid()) {
                Canvas c=null;
                try { c=holder.lockCanvas(); if(c!=null) { synchronized(holder){ drawGame(c); } } }
                catch(Exception ignored) {} finally { if(c!=null) try{holder.unlockCanvasAndPost(c);}catch(Exception ignored){} }
            }
            try { Thread.sleep(16); } catch(InterruptedException ignored){}
        }
    }

    private void drawGame(Canvas real) {
        float sx=real.getWidth()/960f, sy=real.getHeight()/540f;
        scale=Math.min(sx,sy); offsetX=(real.getWidth()-960*scale)/2f; offsetY=(real.getHeight()-540*scale)/2f;
        real.drawColor(Color.rgb(10,10,20));
        real.save(); real.translate(offsetX,offsetY); real.scale(scale,scale);
        screenW=960; screenH=540;
        if(screen==Screen.PLAYING || screen==Screen.TUTORIAL || screen==Screen.CHEST) {
            updateWorld();
            drawWorld(real);
            drawHud(real);
            if(screen==Screen.TUTORIAL) drawTutorial(real);
            if(screen==Screen.CHEST) drawChestDialog(real);
        } else if(screen==Screen.MENU) drawMenu(real);
        else if(screen==Screen.PAUSE) { drawWorld(real); drawHud(real); drawPanel(real,"PAUSED",new String[]{"RESUME","SETTINGS","QUIT & SAVE SCORE"}); }
        else if(screen==Screen.CLEARED) { drawWorld(real); drawStageClear(real); }
        else if(screen==Screen.DEFEAT) { drawWorld(real); drawDefeat(real); }
        else if(screen==Screen.LEVELS) drawLevels(real);
        else if(screen==Screen.SETTINGS) drawSettings(real);
        else if(screen==Screen.INVENTORY) drawInventory(real);
        if(!toast.isEmpty() && System.currentTimeMillis()<toastUntil) { panel(real,300,18,360,38,0xEE17172B); text(real,toast,480,43,17,Color.WHITE,true); }
        real.restore();
    }

    private void updateWorld() {
        long now=System.currentTimeMillis();
        float dt=lastFrame==0?0.016f:Math.min(0.04f,(now-lastFrame)/1000f); lastFrame=now;
        if(screen==Screen.TUTORIAL || screen==Screen.CHEST) return;
        if(joystickActive) { px+=joystickX*115*(1+speedStat*.04f)*dt; py+=joystickY*75*(1+speedStat*.04f)*dt; }
        px=clamp(px,-300,300); py=clamp(py,-170,170);
        for(Enemy e:enemies) {
            float dx=px-e.x, dy=py-e.y, d=(float)Math.sqrt(dx*dx+dy*dy);
            if(d>27) { e.x+=dx/d*e.speed*dt; e.y+=dy/d*e.speed*dt; }
            else if(now%900<35) { int damage=(difficulty.equals("Hard")?12: difficulty.equals("Easy")?5:8)+(e.boss?4:0); hp=Math.max(0,hp-damage); sound(2); if(hp<=0){screen=Screen.DEFEAT;sessionBest=Math.max(sessionBest,level-1);} }
        }
        for(Particle a:particles){a.x+=a.vx*dt;a.y+=a.vy*dt;a.life-=dt;}
        particles.removeIf(a->a.life<=0);
        chestNearby=false;
        for(Chest ch:chests) if(!ch.opened && dist(px,py,ch.x,ch.y)<58) chestNearby=true;
    }

    private void drawWorld(Canvas c) {
        int chapter=(level-1)/5;
        int sky=chapter==2?0xff241b2b:chapter==3?0xff182b42:chapter>=4?0xff17162e:0xff172b35;
        c.drawColor(sky);
        // layered distant scenery gives the arena a true RPG-world silhouette
        for(int i=0;i<9;i++) {
            float bx=i*130-55, base=210+(i%3)*22;
            p.setColor(chapter==2?0xff59352f:chapter==3?0xff29485a:0xff263b43);
            Path ridge=new Path(); ridge.moveTo(bx-35,base+55);ridge.lineTo(bx+22,base-65-(i%2)*35);ridge.lineTo(bx+85,base+55);ridge.close();c.drawPath(ridge,p);
            p.setColor(0x443e5260); c.drawLine(bx+22,base-65-(i%2)*35,bx+45,base+25,p);
        }
        int ground=chapter==0?0xff416b42:chapter==1?0xff414052:chapter==2?0xff814a32:chapter==3?0xff365d75:chapter==4?0xff302746:0xff57304d;
        // diamond tile map with alternating tones, seams and tiny pixel-grass/stone flecks
        for(int y=-6;y<8;y++) for(int x=-9;x<10;x++) {
            float wx=x*82, wy=y*48; float[] pt=iso(wx,wy);
            int tile=((x+y)&1)==0?ground:shade(ground,1.10f);
            Path tilePath=new Path();tilePath.moveTo(pt[0],pt[1]-22);tilePath.lineTo(pt[0]+41,pt[1]);tilePath.lineTo(pt[0],pt[1]+22);tilePath.lineTo(pt[0]-41,pt[1]);tilePath.close();
            p.setColor(tile);c.drawPath(tilePath,p);
            p.setColor(0x55302c35);c.drawLine(pt[0]-41,pt[1],pt[0],pt[1]+22,p);c.drawLine(pt[0],pt[1]+22,pt[0]+41,pt[1],p);
            if(((x*7+y*11)&3)==0){p.setColor(chapter==0?0xff71924d:chapter==2?0xffd08a4e:0xff7e8290);c.drawRect(pt[0]-12,pt[1]-5,pt[0]-7,pt[1]-2,p);c.drawRect(pt[0]+10,pt[1]+3,pt[0]+15,pt[1]+6,p);}
        }
        // scenery is deliberately placed behind actors
        for(int i=0;i<7;i++){float[] q=iso(-350+i*116,(i%2==0)?-190:190);drawTree(c,q[0],q[1],chapter);}
        for(int i=0;i<4;i++){float[] q=iso(-280+i*185,-130+(i%2)*240);drawHouse(c,q[0],q[1],chapter);}
        for(Chest ch:chests){float[] q=iso(ch.x,ch.y);drawChest(c,q[0],q[1],ch.opened);}
        // painter's order by depth
        ArrayList<Object> actors=new ArrayList<>(); actors.addAll(enemies); actors.add("PLAYER");
        actors.sort((a,b)->Float.compare(a instanceof Enemy?((Enemy)a).x+((Enemy)a).y:px+py,b instanceof Enemy?((Enemy)b).x+((Enemy)b).y:px+py));
        for(Object actor:actors){if(actor instanceof Enemy){Enemy e=(Enemy)actor;float[] q=iso(e.x,e.y);drawEnemy(c,q[0],q[1],e);}else{float[] q=iso(px,py);drawHero(c,q[0],q[1]);}}
        for(Particle a:particles){float[] q=iso(a.x,a.y);text(c,a.text,q[0],q[1]-35,17,a.color,true);}
        panel(c,16,12,220,32,0xAA101522);text(c,"CHAPTER "+(chapter+1)+": "+chapters[chapter],26,34,13,0xffffdf9b,false);
    }
    private void drawTree(Canvas c,float x,float y,int chapter){
        p.setColor(0x77000000);c.drawOval(x-20,y+1,x+20,y+10,p);
        rect(c,x-5,y-28,x+5,y+8,0xff60432f);
        int leaf=chapter==2?0xffa34c35:chapter==3?0xff4c9b9b:chapter>=4?0xff684a91:0xff28613d;
        rect(c,x-19,y-45,x+19,y-22,leaf);rect(c,x-14,y-57,x+14,y-39,shade(leaf,1.22f));
        rect(c,x-23,y-35,x-13,y-26,shade(leaf,.78f));rect(c,x+12,y-40,x+22,y-30,shade(leaf,.82f));
        rect(c,x-8,y-51,x-3,y-46,0xffa6c76a);
    }
    private float[] iso(float x,float y) { return new float[]{480+(x-y)*.72f,280+(x+y)*.36f}; }
    private void drawHero(Canvas c,float x,float y) {
        boolean mage=hero.equals("Mage");
        p.setColor(0x88000000);c.drawOval(x-18,y+3,x+18,y+12,p);
        // boots and legs
        rect(c,x-12,y-8,x-3,y+8,0xff302b36);rect(c,x+3,y-8,x+12,y+8,0xff302b36);
        rect(c,x-14,y+3,x-2,y+9,0xff79513c);rect(c,x+2,y+3,x+14,y+9,0xff79513c);
        // cloak silhouette and tunic
        if(!mage){Path cape=new Path();cape.moveTo(x-10,y-30);cape.lineTo(x+12,y-29);cape.lineTo(x+18,y+2);cape.lineTo(x-17,y+2);cape.close();p.setColor(0xff8f293e);c.drawPath(cape,p);}
        rect(c,x-12,y-32,x+12,y-9,mage?0xff49377e:0xff31547f);
        rect(c,x-10,y-29,x+10,y-25,mage?0xff8e75d1:0xffd5b56e);
        rect(c,x-13,y-20,x+13,y-16,mage?0xff34265f:0xff263d60);
        // arms, gloves and shoulder plates
        rect(c,x-17,y-29,x-10,y-13,mage?0xffc9c5df:0xffaebdcc);rect(c,x+10,y-29,x+17,y-13,mage?0xffc9c5df:0xffaebdcc);
        rect(c,x-18,y-15,x-9,y-9,0xffd7ad83);rect(c,x+9,y-15,x+18,y-9,0xffd7ad83);
        // face, hair and expressive pixel highlights
        rect(c,x-9,y-47,x+9,y-29,0xffe8b98e);rect(c,x-10,y-48,x+10,y-43,mage?0xffd7d8e9:0xff343044);
        rect(c,x-10,y-46,x-5,y-38,mage?0xffd7d8e9:0xff343044);rect(c,x+5,y-46,x+11,y-38,mage?0xffd7d8e9:0xff343044);
        rect(c,x-6,y-39,x-3,y-37,0xff29233a);rect(c,x+3,y-39,x+6,y-37,0xff29233a);
        rect(c,x-2,y-33,x+3,y-31,0xffbd796e);
        if(mage){rect(c,x-14,y-53,x+14,y-48,0xff49316e);rect(c,x-7,y-59,x+7,y-53,0xff7053a9);rect(c,x+15,y-32,x+18,y+2,0xff7854b5);rect(c,x+12,y-39,x+21,y-31,0xffc6a7ff);rect(c,x+14,y-43,x+19,y-39,0xfff2e7ff);}
        else {rect(c,x-14,y-53,x+14,y-47,0xffaeb9c8);rect(c,x-12,y-47,x-8,y-40,0xffaeb9c8);rect(c,x-19,y-31,x-12,y-20,0xffb8c6d6);rect(c,x+12,y-31,x+19,y-20,0xffb8c6d6);rect(c,x+17,y-39,x+20,y+1,0xffb8c8dc);rect(c,x+13,y-44,x+24,y-39,0xffe2c477);}
        // tiny highlight pixels make the sprite read as pixel art, not a flat primitive
        rect(c,x-8,y-27,x-4,y-24,0xfff1d8a2);rect(c,x+5,y-13,x+9,y-10,0xff7897b7);
    }
    private void drawEnemy(Canvas c,float x,float y,Enemy e) {
        p.setColor(0x88000000);c.drawOval(x-17,y+3,x+17,y+11,p);
        int body=e.boss?0xff702e46:e.type==0?0xff527d3d:e.type==1?0xff9b9eaa:0xff59417f;
        // body silhouette, shoulder armor and legs
        rect(c,x-12,y-25,x+12,y+5,body);rect(c,x-13,y-20,x-7,y-7,shade(body,.72f));rect(c,x+7,y-20,x+13,y-7,shade(body,1.2f));
        rect(c,x-10,y+1,x-3,y+10,0xff302a35);rect(c,x+3,y+1,x+10,y+10,0xff302a35);
        rect(c,x-10,y-37,x+10,y-23,e.boss?0xffb9a2a0:0xffaaa99c);
        rect(c,x-12,y-39,x+12,y-34,e.boss?0xff4a263e:0xff4b4b53);
        rect(c,x-7,y-31,x-3,y-28,0xffff514b);rect(c,x+3,y-31,x+7,y-28,0xffff514b);
        if(e.type==0){rect(c,x-15,y-44,x-8,y-37,0xff557d3e);rect(c,x+8,y-44,x+15,y-37,0xff557d3e);}
        if(e.type==1){rect(c,x-13,y-42,x-8,y-35,0xffc8cbd2);rect(c,x+8,y-42,x+13,y-35,0xffc8cbd2);}
        if(e.boss){rect(c,x-20,y-48,x-13,y-34,0xffd0a84f);rect(c,x+13,y-48,x+20,y-34,0xffd0a84f);rect(c,x-24,y-55,x+24,y-49,0xff211a2b);rect(c,x-23,y-54,x-23+46*(e.hp/e.maxHp),y-50,0xffe35b58);text(c,e.name,x,y-62,12,0xffffdfb0,true);}
        else {rect(c,x-12,y-46,x+12,y-43,0xff241b24);rect(c,x-11,y-45,x-11+22*(e.hp/e.maxHp),y-44,0xff79df69);}
    }
    private void drawHouse(Canvas c,float x,float y,int chapter) {
        p.setColor(0x77000000);c.drawOval(x-38,y+1,x+38,y+12,p);
        int wall=chapter==2?0xff754336:chapter==3?0xff496777:0xff79553e;
        rect(c,x-28,y-38,x+28,y+5,wall);rect(c,x-24,y-34,x-19,y+1,shade(wall,1.2f));rect(c,x+18,y-34,x+23,y+1,shade(wall,.72f));
        Path roof=new Path();roof.moveTo(x-36,y-37);roof.lineTo(x,y-67);roof.lineTo(x+36,y-37);roof.close();p.setColor(chapter==2?0xffa34b36:0xff49344a);c.drawPath(roof,p);
        p.setColor(0xffb77855);c.drawLine(x-30,y-37,x,y-62,p);c.drawLine(x,y-62,x+30,y-37,p);
        rect(c,x-8,y-22,x+8,y+5,0xff392c2a);rect(c,x-22,y-29,x-12,y-17,0xff9bd6e5);rect(c,x-20,y-27,x-14,y-19,0xffd9f2e8);
        rect(c,x-2,y-18,x+2,y-14,0xffffd16b);
    }
    private void drawChest(Canvas c,float x,float y,boolean opened) {
        rect(c,x-13,y-13,x+13,y+5,opened?0xff60462e:0xffa66a2d);
        rect(c,x-14,y-17,x+14,y-8,opened?0xff4c3c2f:0xffffc34c);
        rect(c,x-2,y-11,x+2,y-5,0xffffe18a);
    }

    private void drawHud(Canvas c) {
        panel(c,16,54,220,64,0xDD111827);
        text(c,playerName+"  Lv."+playerLevel,28,76,15,Color.WHITE,false);
        bar(c,28,84,185,9,hp/(float)maxHp,0xffd84b57);text(c,"HP "+hp+"/"+maxHp,30,104,11,Color.WHITE,false);
        bar(c,28,108,185,7,mana/(float)maxMana,0xff4d9de8);
        panel(c,750,12,194,54,0xCC111827);text(c,"STAGE "+level+"/30",766,34,16,0xffffdf9b,false);text(c,"Gold: "+gold,766,54,14,Color.WHITE,false);
        button(c,815,435,120,82,"⚔ ATTACK",0xffa33b4b);
        button(c,686,450,105,64,"✦ SKILL",0xff5544a1);
        button(c,16,430,138,96,"MOVE",0xff39465d);
        if(chestNearby) button(c,390,445,180,65,"OPEN CHEST",0xffa46c28);
        button(c,16,126,90,34,"BAG",0xff39465d);
        button(c,112,126,90,34,"PAUSE",0xff39465d);
        text(c,"Enemies: "+enemies.size(),770,85,13,0xffeeeeee,false);
        bar(c,770,92,155,7,Math.max(0,hp)/(float)maxHp,0xffc74454);
    }

    private void drawMenu(Canvas c) {
        drawBackdrop(c);
        text(c,"LEGENDS OF",480,105,28,0xffe9d7ff,true);
        text(c,"MATHEMATICA",480,151,48,0xffffd47d,true);
        text(c,"FIGHT • SOLVE • SURVIVE",480,180,15,0xffc7b8e8,true);
        button(c,350,220,260,48,"START GAME",0xff315f9e);
        button(c,350,278,260,42,"SETTINGS",0xff39344e);
        button(c,350,330,260,42,"LEVEL SELECT",0xff39344e);
        button(c,350,382,260,42,"HIGH SCORE: "+sessionBest,0xff39344e);
        button(c,350,434,260,42,"CREDITS",0xff39344e);
        text(c,"A pixel-art adventure where every treasure is earned.",480,510,13,0xffb8b3ca,true);
    }
    private void drawBackdrop(Canvas c) {
        c.drawColor(0xff17162d);
        for(int i=0;i<18;i++){float x=(i*73)%960,y=(i*127)%540;rect(c,x,y,x+3,y+3,0xffa58ce9);}
        for(int i=0;i<7;i++){float x=i*155-30;rect(c,x,330-(i%3)*25,x+100,520,0xff292744);rect(c,x+35,260-(i%3)*25,x+65,390,0xff3b3157);}
        rect(c,0,470,960,540,0xff101321);
    }
    private void drawPanel(Canvas c,String title,String[] labels) {
        drawBackdrop(c);panel(c,260,80,440,380,0xee171629);text(c,title,480,135,30,0xffffd47d,true);
        for(int i=0;i<labels.length;i++)button(c,340,175+i*75,280,54,labels[i],0xff41405f);
    }
    private void drawTutorial(Canvas c) {
        panel(c,180,150,600,230,0xf51a1b30);text(c,"WELCOME, "+playerName.toUpperCase()+"!",480,190,23,0xffffd47d,true);
        text(c,"Drag the left joystick to move around the isometric world.",480,235,16,Color.WHITE,true);
        text(c,"Use ATTACK to defeat monsters. SKILL spends mana.",480,265,16,Color.WHITE,true);
        text(c,"Walk near a chest, solve its math puzzle, and claim loot.",480,295,16,Color.WHITE,true);
        button(c,390,325,180,42,"BEGIN ADVENTURE",0xff386caa);
    }
    private void drawChestDialog(Canvas c) {
        panel(c,260,115,440,320,0xf51b1a2b);text(c,"TREASURE CHALLENGE",480,155,24,0xffffd47d,true);
        text(c,"Solve to unlock the chest!",480,190,16,Color.WHITE,true);
        text(c,question,480,245,35,0xffe9d5ff,true);
        panel(c,370,270,220,42,0xff302d47);text(c,answer.isEmpty()?"Tap number buttons below":answer,480,297,20,Color.WHITE,true);
        for(int i=0;i<10;i++)button(c,300+(i%5)*73,325+(i/5)*45,64,37,""+i,0xff414c70);
        button(c,670,325,90,37,"ENTER",0xff347a58);button(c,400,420,160,38,"CANCEL",0xff6d3d4a);
    }
    private void drawStageClear(Canvas c) {
        drawBackdrop(c);panel(c,220,85,520,370,0xf21b1a2b);text(c,"STAGE CLEARED!",480,145,34,0xffffd36d,true);
        text(c,"Enemies defeated: "+enemiesDefeated,480,210,20,Color.WHITE,true);
        text(c,"Gold earned: "+stageGold,480,245,20,0xffffd36d,true);
        text(c,"Experience gained: "+(35+level*5),480,280,18,0xffb8d8ff,true);
        button(c,285,340,180,54,"NEXT STAGE",0xff34764f);button(c,495,340,180,54,"LEVEL SELECT",0xff4c4389);
    }
    private void drawDefeat(Canvas c) {
        drawBackdrop(c);panel(c,260,110,440,320,0xf21b1a2b);text(c,"YOU HAVE FALLEN",480,170,32,0xffe36b76,true);
        text(c,"Your journey is not over.",480,220,18,Color.WHITE,true);
        button(c,350,270,260,48,"RETRY STAGE",0xffa34a4c);button(c,350,330,260,48,"LEVEL SELECT",0xff4b4687);
    }
    private void drawLevels(Canvas c) {
        drawBackdrop(c);text(c,"CHOOSE YOUR STAGE",480,55,28,0xffffd47d,true);
        for(int i=1;i<=30;i++){int col=(i-1)%6,row=(i-1)/6;int x=165+col*108,y=105+row*70;button(c,x,y,86,52,(i<=maxUnlocked?"":"🔒 ")+i,i<=maxUnlocked?0xff3d5d87:0xff34313e);}
        button(c,20,20,110,40,"BACK",0xff5a3f4c);
    }
    private void drawSettings(Canvas c) {
        drawBackdrop(c);panel(c,220,65,520,410,0xf21b1a2b);text(c,"SETTINGS",480,110,30,0xffffd47d,true);
        text(c,"Player name: "+playerName,480,165,18,Color.WHITE,true);
        button(c,330,185,140,42,"KNIGHT",hero.equals("Knight")?0xff315f9e:0xff41405f);
        button(c,490,185,140,42,"MAGE",hero.equals("Mage")?0xff7653a5:0xff41405f);
        text(c,"Difficulty: "+difficulty,480,265,19,Color.WHITE,true);
        button(c,285,285,115,42,"EASY",0xff3d7658);button(c,422,285,115,42,"NORMAL",0xff55517d);button(c,560,285,115,42,"HARD",0xff93464a);
        text(c,"Tap NAME to change it (default: Knight).",480,365,15,0xffc8c3d8,true);
        button(c,390,410,180,42,"BACK",0xff41405f);
    }
    private void drawInventory(Canvas c) {
        drawBackdrop(c);panel(c,120,45,720,450,0xf21b1a2b);text(c,"HERO & INVENTORY",480,90,28,0xffffd47d,true);
        drawHero(c,300,235);text(c,hero+" • "+playerName,300,290,17,Color.WHITE,true);
        text(c,"Level "+playerLevel+"     XP "+xp+"     Attribute points: "+points,590,145,17,Color.WHITE,true);
        text(c,"Weapon power: "+weaponPower+"     Armor: "+armor,590,185,17,0xffe5d5ff,true);
        String[] attrs={"Attack: "+attackStat,"Speed: "+speedStat,"Mana: "+manaStat,"Durability: "+durabilityStat};
        for(int i=0;i<4;i++){button(c,470,220+i*48,170,38,attrs[i],0xff343c59);button(c,655,220+i*48,60,38,"+ ",points>0?0xff39734d:0xff555555);}
        button(c,400,435,160,42,"BACK",0xff41405f);
    }

    private void attack() {
        long now=System.currentTimeMillis(); if(now-lastAttack<420)return;lastAttack=now;sound(1);
        boolean hit=false;
        for(Enemy e:enemies) if(dist(px,py,e.x,e.y)<105) {int dmg=12+weaponPower*4+attackStat*3+(hero.equals("Mage")?2:0);e.hp-=dmg;particles.add(new Particle(e.x,e.y-25,"-"+dmg,0xffffe17a));hit=true;}
        enemies.removeIf(e->{if(e.hp<=0){enemiesDefeated++;int g=e.boss?100:8+random.nextInt(9);gold+=g;stageGold+=g;xp+=e.boss?100:15;if(xp>=playerLevel*60 && playerLevel<32){xp=0;playerLevel++;points+=2;maxHp+=8;maxMana+=4;hp=maxHp;mana=maxMana;toast("LEVEL UP! +2 attribute points",2200);}return true;}return false;});
        if(!hit) toast("No enemy in range",700);
        if(enemies.isEmpty()) clearStage();
    }
    private void useSkill() {
        long now=System.currentTimeMillis();if(now<skillReadyAt){toast("Skill cooling down!",700);return;}
        if(mana<25){toast("Not enough mana!",700);return;}mana-=25;skillReadyAt=now+6500;sound(3);
        int hit=0;for(Enemy e:enemies)if(dist(px,py,e.x,e.y)<155){int d=26+attackStat*4;e.hp-=d;particles.add(new Particle(e.x,e.y-25,"-"+d,0xffbca6ff));hit++;}
        if(hero.equals("Mage")){int heal=25+manaStat*4;hp=Math.min(maxHp,hp+heal);toast("Holy Light: restored "+heal+" HP",1100);}
        else toast("Blade Whirlwind! "+hit+" enemies hit",1100);
        enemies.removeIf(e->{if(e.hp<=0){enemiesDefeated++;gold+=12;stageGold+=12;xp+=20;return true;}return false;});
        if(enemies.isEmpty())clearStage();
    }
    private void clearStage() {screen=Screen.CLEARED;maxUnlocked=Math.max(maxUnlocked,Math.min(30,level+1));sessionBest=Math.max(sessionBest,level);sound(4);}
    private void startStage(int n) {
        level=Math.max(1,Math.min(30,n));screen=Screen.PLAYING;hp=maxHp;mana=maxMana;px=py=0;stageGold=0;enemiesDefeated=0;enemies.clear();chests.clear();particles.clear();lastFrame=0;
        int count=level%5==0?1:5+Math.min(5,level/3);
        for(int i=0;i<count;i++){float x=(random.nextFloat()-.5f)*440,y=(random.nextFloat()-.5f)*270;boolean boss=level%5==0;String nm=boss?bossNames[(level/5-1)%bossNames.length]:i%3==0?"Goblin":i%3==1?"Skeleton":"Voidling";float h=(boss?260:45+level*7)*(difficulty.equals("Easy")?.75f:difficulty.equals("Hard")?1.7f:1f);enemies.add(new Enemy(x,y,i%3,boss,h,nm));}
        for(int i=0;i<2;i++)chests.add(new Chest((random.nextFloat()-.5f)*430,(random.nextFloat()-.5f)*260));
        if(level==1)screen=Screen.TUTORIAL;
        toast("Entering "+chapters[(level-1)/5],1200);
    }
    private void makeQuestion() {
        int a,b;String op;
        if(difficulty.equals("Easy")){a=1+random.nextInt(20);b=1+random.nextInt(20);op=random.nextBoolean()?"+":"-";if(op.equals("-")&&b>a){int t=a;a=b;b=t;}correctAnswer=op.equals("+")?a+b:a-b;}
        else if(difficulty.equals("Hard")){a=2+random.nextInt(12);b=2+random.nextInt(12);int mode=random.nextInt(3);if(mode==0){op="×";correctAnswer=a*b;}else if(mode==1){correctAnswer=a; a=a*b;op="÷";}else{op="×";correctAnswer=a*b+random.nextInt(9);}}
        else {a=2+random.nextInt(12);b=2+random.nextInt(12);op=random.nextBoolean()?"+":"×";correctAnswer=op.equals("+")?a+b:a*b;}
        question=a+" "+op+" "+b+" = ?";answer="";
    }
    private void submitAnswer() {
        int val;try{val=Integer.parseInt(answer);}catch(Exception e){toast("Enter an answer first",900);return;}
        if(val==correctAnswer){for(Chest ch:chests)if(!ch.opened&&dist(px,py,ch.x,ch.y)<58){ch.opened=true;int reward=difficulty.equals("Hard")?3:difficulty.equals("Normal")?2:1;weaponPower+=reward;int g=35+random.nextInt(45);gold+=g;stageGold+=g;toast("Correct! Weapon +"+reward+" • Gold +"+g,1600);sound(4);break;}}
        else toast("Not quite! Try another chest later.",1200);
        screen=Screen.PLAYING;answer="";
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        float x=(e.getX()-offsetX)/scale,y=(e.getY()-offsetY)/scale;
        int action=e.getActionMasked(),idx=e.getActionIndex();
        if(action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_POINTER_DOWN) {
            x=(e.getX(idx)-offsetX)/scale;y=(e.getY(idx)-offsetY)/scale;
            if(screen==Screen.MENU){if(hit(x,y,350,220,610,268)){startStage(1);}else if(hit(x,y,350,278,610,320)){screen=Screen.SETTINGS;}else if(hit(x,y,350,330,610,372)){screen=Screen.LEVELS;}else if(hit(x,y,350,382,610,424)){toast("Session best: stage "+sessionBest,1800);}else if(hit(x,y,350,434,610,476)){toast("Ideas: Aqua Hoshino • AI assistance: Gemini AI",2500);}return true;}
            if(screen==Screen.TUTORIAL){if(hit(x,y,390,325,570,367))screen=Screen.PLAYING;return true;}
            if(screen==Screen.CHEST){if(hit(x,y,400,420,560,458)){screen=Screen.PLAYING;return true;}for(int i=0;i<10;i++)if(hit(x,y,300+(i%5)*73,325+(i/5)*45,364+(i%5)*73,362+(i/5)*45)){answer+=i;return true;}if(hit(x,y,670,325,760,362)){submitAnswer();return true;}return true;}
            if(screen==Screen.PAUSE){if(hit(x,y,340,175,620,229)){screen=Screen.PLAYING;}else if(hit(x,y,340,250,620,304)){screen=Screen.SETTINGS;}else if(hit(x,y,340,325,620,379)){sessionBest=Math.max(sessionBest,level);screen=Screen.MENU;}return true;}
            if(screen==Screen.CLEARED){if(hit(x,y,285,340,465,394)){if(level<30)startStage(level+1);else screen=Screen.MENU;}else if(hit(x,y,495,340,675,394))screen=Screen.LEVELS;return true;}
            if(screen==Screen.DEFEAT){if(hit(x,y,350,270,610,318))startStage(level);else if(hit(x,y,350,330,610,378))screen=Screen.LEVELS;return true;}
            if(screen==Screen.LEVELS){if(hit(x,y,20,20,130,60)){screen=Screen.MENU;return true;}for(int i=1;i<=30;i++){int col=(i-1)%6,row=(i-1)/6;int bx=165+col*108,by=105+row*70;if(i<=maxUnlocked&&hit(x,y,bx,by,bx+86,by+52)){startStage(i);return true;}}return true;}
            if(screen==Screen.SETTINGS){if(hit(x,y,330,185,470,227)){hero="Knight";}else if(hit(x,y,490,185,630,227)){hero="Mage";}else if(hit(x,y,285,285,400,327)){difficulty="Easy";}else if(hit(x,y,422,285,537,327)){difficulty="Normal";}else if(hit(x,y,560,285,675,327)){difficulty="Hard";}else if(hit(x,y,390,410,570,452))screen=Screen.MENU;else if(hit(x,y,370,140,590,178)){playerName=playerName.equals("Knight")?"Aria":"Knight";}return true;}
            if(screen==Screen.INVENTORY){if(hit(x,y,400,435,560,477))screen=Screen.PLAYING;else for(int i=0;i<4;i++)if(hit(x,y,655,220+i*48,715,258+i*48)&&points>0){if(i==0&&attackStat<10)attackStat++;else if(i==1&&speedStat<10)speedStat++;else if(i==2&&manaStat<10){manaStat++;maxMana+=5;}else if(i==3&&durabilityStat<10){durabilityStat++;maxHp+=10;hp=maxHp;}else {toast("Attribute maxed",800);return true;}points--;return true;}return true;}
            if(screen==Screen.PLAYING){
                if(hit(x,y,112,126,202,160)){screen=Screen.PAUSE;joystickActive=false;return true;}
                if(hit(x,y,16,126,106,160)){screen=Screen.INVENTORY;joystickActive=false;return true;}
                if(hit(x,y,815,435,935,517)){attack();return true;}
                if(hit(x,y,686,450,791,514)){useSkill();return true;}
                if(chestNearby&&hit(x,y,390,445,570,510)){makeQuestion();screen=Screen.CHEST;return true;}
                if(hit(x,y,16,430,154,526)){joystickActive=true;joystickX=0;joystickY=0;return true;}
                joystickActive=true;joystickX=clamp((x-85)/65,-1,1);joystickY=clamp((y-478)/45,-1,1);return true;
            }
        }
        if(action==MotionEvent.ACTION_MOVE&&screen==Screen.PLAYING&&joystickActive){
            int pointer=e.findPointerIndex(0);if(pointer>=0){float tx=(e.getX(pointer)-offsetX)/scale,ty=(e.getY(pointer)-offsetY)/scale;joystickX=clamp((tx-85)/65,-1,1);joystickY=clamp((ty-478)/45,-1,1);}return true;
        }
        if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_POINTER_UP||action==MotionEvent.ACTION_CANCEL){joystickActive=false;joystickX=joystickY=0;return true;}
        return true;
    }

    private void sound(int kind){try{if(tones!=null)tones.startTone(kind==1?ToneGenerator.TONE_PROP_ACK:kind==2?ToneGenerator.TONE_PROP_NACK:kind==3?ToneGenerator.TONE_DTMF_5:ToneGenerator.TONE_PROP_BEEP,100);}catch(Exception ignored){}}
    private void toast(String s,int ms){toast=s;toastUntil=System.currentTimeMillis()+ms;}
    private void panel(Canvas c,float x,float y,float w,float h,int color){p.setColor(color);c.drawRoundRect(x,y,x+w,y+h,9,9,p);p.setColor(0xff9b8bc1);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);c.drawRoundRect(x,y,x+w,y+h,9,9,p);p.setStyle(Paint.Style.FILL);}
    private void button(Canvas c,float x,float y,float w,float h,String s,int color){panel(c,x,y,w,h,color);text(c,s,x+w/2,y+h/2+6,Math.min(18,h*.34f),Color.WHITE,true);}
    private void text(Canvas c,String s,float x,float y,float size,int color,boolean center){p.setColor(color);p.setTextSize(size);p.setTextAlign(center?Paint.Align.CENTER:Paint.Align.LEFT);p.setStyle(Paint.Style.FILL);c.drawText(s,x,y,p);}
    private void rect(Canvas c,float l,float t,float r,float b,int color){p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRect(l,t,r,b,p);}
    private void bar(Canvas c,float x,float y,float w,float h,float ratio,int color){rect(c,x,y,x+w,y+h,0xff29283a);rect(c,x,y,x+w*clamp(ratio,0,1),y+h,color);}
    private boolean hit(float x,float y,float l,float t,float r,float b){return x>=l&&x<=r&&y>=t&&y<=b;}
    private float dist(float x,float y,float a,float b){return (float)Math.sqrt((x-a)*(x-a)+(y-b)*(y-b));}
    private float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}
    private int shade(int color,float f){return Color.rgb(Math.min(255,(int)(Color.red(color)*f)),Math.min(255,(int)(Color.green(color)*f)),Math.min(255,(int)(Color.blue(color)*f)));}
}
