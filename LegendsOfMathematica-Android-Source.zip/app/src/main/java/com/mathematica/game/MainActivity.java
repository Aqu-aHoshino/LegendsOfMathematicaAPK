package com.mathematica.game;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
    private GameView gameView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
                5894 | 1024 | 512 | 4096);
        gameView = new GameView(this);
        setContentView(gameView);
    }

    @Override protected void onPause() {
        super.onPause();
        if (gameView != null) gameView.pauseGame();
    }

    @Override protected void onResume() {
        super.onResume();
        if (gameView != null) gameView.resumeGame();
    }
}
