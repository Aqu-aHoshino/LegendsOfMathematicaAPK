# Legends Of Mathematica — Android source project

A native Android Java prototype for the isometric medieval RPG concept. It uses Android's
`SurfaceView` and `Canvas` directly; no Unity, Godot, LibGDX, or external game engine is used.

## Uploading the project as a ZIP

The project ZIP includes the Android source and a GitHub Actions workflow.

**GitHub limitation:** GitHub does not automatically unpack ZIP files uploaded to a repository,
and it only recognizes workflow files that are already placed in the repository at
`.github/workflows/`. Therefore, the workflow must be added to the repository once before
ZIP-only updates can trigger automatic builds.

For the initial setup:
1. Create a GitHub repository.
2. Add the workflow file from `.github/workflows/android-build.yml` to the repository at that exact path.
3. Upload this project archive to the repository root, naming it
   `LegendsOfMathematica-Android-Source.zip`.
4. The workflow extracts the archive, builds the Android app, and uploads the APK artifact.

For later updates, replace `LegendsOfMathematica-Android-Source.zip` in the repository.
The workflow will run automatically when that ZIP changes.

## Download the APK

When the GitHub Actions run finishes successfully:
1. Open the completed run under the repository's **Actions** tab.
2. Find **Artifacts**.
3. Download `LegendsOfMathematica-debug-apk`.
4. Extract the downloaded artifact ZIP to get `app-debug.apk`.

## Build locally

Open the project root in Android Studio, allow Gradle sync, then run the `app` configuration.
Alternatively, with Java 17 and Android SDK installed, run:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Current playable prototype

- Landscape-only Android app with a custom pixel-style isometric renderer.
- Knight and Mage visual choices.
- Main menu, settings, level select, pause, inventory, victory and defeat screens.
- 30-stage progression structure and boss encounter every fifth stage.
- Four-way on-screen D-pad movement with multi-touch support.
- MOBA-style combat controls: basic attack plus three class skills with separate cooldowns and mana costs.
- Enemies pursue the player and have health bars.
- Math chest challenges with Easy, Normal and Hard question generation.
- Gold, weapon upgrades, XP and attribute-point allocation.
- Hybrid Canvas and hand-made pixel-art rendering with CC0 forest and cave sprites, plus synthesized tone effects.

## Controls (v0.3.0)

- Hold the four-way D-pad at the bottom-left to move; diagonal movement is supported.
- Tap ATK for a basic attack.
- Q: Shield Break (Knight) / Arcane Bolt (Mage) — single-target burst.
- W: Whirlwind (Knight) / Frost Nova (Mage) — area damage; Mage also slows enemies.
- E: Guardian's Resolve (Knight) / Starfall (Mage) — defensive sustain or high-damage area burst.
- Skill costs/cooldowns: Q = 12 MP / 4s, W = 20 MP / 7s, E = 30 MP / 12s. The HUD displays remaining cooldown and mana cost.
- Walk close to a chest and tap OPEN CHEST, then enter the answer with the on-screen number pad.
- BAG opens inventory; PAUSE opens the pause menu.

## Notes

This is a prototype/gameplay foundation, not yet the complete production game described in the design brief.

## Graphics upgrade (GBA-inspired isometric pass)

This revision upgrades the Canvas renderer with layered chapter backdrops, richer isometric ground tiles, scenery silhouettes, pixel-cluster trees, more detailed Knight/Mage and enemy designs, and improved building/chest presentation. It remains a native Android Java `SurfaceView` project and keeps the existing gameplay systems.

A custom Legends Of Mathematica launcher icon is included in the Android mipmap resources and configured in `AndroidManifest.xml`.

Note: this is an improved procedural pixel-art rendering pass, not yet a complete hand-authored sprite-sheet/tileset production. The project should be built and tested on-device; successful compilation does not guarantee every visual or gameplay detail is finished.


## CC0 art integrated

The project includes selected original pixel-art assets from these uploaded packs:
- **KipperFalcon — Forest Isometric Pack Free**: tree sprites, grass tile, and supporting atlas files. License text is included at `app/src/main/assets/forest/LICENSE_CC0.txt`.
- **KipperFalcon — 2D Isometric Cave Tiles**: stone/lava tiles, portal, crystals, and atlas files. License text is included at `app/src/main/assets/cave/LICENSE_CC0.txt`.

The Devil's Workshop pack was not integrated because its included license is not CC0. The uploaded character sprite archive was not integrated because it contains no license/readme proving CC0 rights. The original Knight/Mage Canvas designs, enemy/boss renderer, and Android launcher icon are therefore preserved rather than replaced with unverified art.

## Controls and gameplay update

This revision replaces the previous joystick and single-skill control layout with a four-way D-pad, a basic attack button, and three class-specific skills. The D-pad and combat buttons support multi-touch so movement can be held while attacking or casting.

## v0.3.0 art and Android support
- Android 11 (API 30) or newer is required (`minSdk 30`); target SDK is API 35.
- Selected user-provided character sprites are used for the Knight, Mage, three enemy types, and bosses.
- Original procedural character/enemy drawing remains as a fallback.
- Character sprite archive license was not present in the supplied ZIP. The project owner authorized personal-project use; do not publish or commercially distribute those sprites until the original license is verified.
