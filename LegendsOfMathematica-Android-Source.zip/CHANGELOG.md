# Changelog

## v0.2.0
- Replaced the single joystick-style movement area with a four-way D-pad.
- Added multi-touch movement so the player can hold a direction while using combat controls.
- Added a basic attack button plus three class-specific skills with individual mana costs and cooldowns.
- Knight skills: Shield Break, Whirlwind, Guardian's Resolve.
- Mage skills: Arcane Bolt, Frost Nova, Starfall.
- Added CC0 forest trees, grass accents, cave stone/lava tiles, portals, and mineral props.
- Preserved the original launcher icon, Knight/Mage procedural designs, stage progression, enemy/boss systems, inventory, and math-chest gameplay.

## v0.3.0
- Added selected pixel-art Knight and Mage character sprites.
- Added Goblin, Armored, and Shadow enemy sprites plus a larger boss sprite.
- Kept the original procedural renderer as a fallback if a sprite fails to load.
- Updated Android minimum supported version to Android 11 (API 30) and target SDK to API 35.
- Added an asset-source note documenting that the character archive's license was not included; use is authorized by the project owner for this personal project, but public redistribution requires verification.
